using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ContactForm_new.Pages.contacts
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
