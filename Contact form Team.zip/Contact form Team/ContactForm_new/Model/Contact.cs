﻿using System.ComponentModel.DataAnnotations;

namespace ContactForm_new.Model
{
    /// <summary>
    /// completed by Mounika and Harshitha
    /// </summary>
    public class Contact
    {
        public int Id { get; set; }

        public string? Name { get; set; }

        public string? Email { get; set; }

        public string? Subject { get; set; }

        public string? Message { get; set; }
    }
}
