﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;

namespace ContactForm_new.Model
{
    /// <summary>
    /// completed by Mounika and Harshitha
    /// </summary>
    public class ContactformContext:DbContext
    {
        public ContactformContext(DbContextOptions<ContactformContext> options) :base(options)
        {
               
        }

        public DbSet<Contact> Contacts { get; set; }
    }
}
